package com.sutton.Test.constant;

/**
 * @version 1.0.1
 * @program: nirvana
 * @description:
 * @author: Mr.wang.sutton
 * @create: 2022-10-24 22:10
 **/
public class FileStudentScoreConstant {
    /**
     * 分数
     */
    public static Double SCORE=5.0;
}
