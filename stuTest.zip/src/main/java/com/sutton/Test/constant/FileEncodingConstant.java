package com.sutton.Test.constant;

/**
 * @version 1.0.1
 * @program: nirvana
 * @description: 编码常量
 * @author: Mr.wang.sutton
 * @create: 2022-10-24 17:18
 **/
public class FileEncodingConstant {

    /**
     * 编码
     */
    public static String ENCODING_UTF = "UTF-8";


}
